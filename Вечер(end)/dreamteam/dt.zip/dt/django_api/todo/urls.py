from django.urls import path

from .views import *

urlpatterns = [
    path('list/', PersonAPIView.as_view()),
]